'use client'

import { useCallback, useEffect, useState } from 'react'
import { Save, SlidersHorizontal, AlertCircle, CheckCircle2 } from 'lucide-react'
import { api, ApiError } from '../../lib/api'

type StrategyParams = {
  take_profit_pct: number
  stop_loss_mult: number
  roll_delta: number
  roll_min_dte: number
  delta_min: number
  delta_max: number
  dte_min: number
  dte_max: number
  max_concentration_pct: number
  min_cash_reserve_pct: number
  // Scalping mode — mirrors StrategyConfigModel in backend/app/routes/strategy.py.
  // These were rendered and sent in the PUT body but missing from the type, so
  // `next build` failed on DEFAULTS and the two safeguard fields were never
  // seeded (the backend requires scalp_max_daily_loss_pct).
  scalp_mode: boolean
  scalp_min_dte: number
  scalp_max_dte: number
  scalp_delta_min: number
  scalp_delta_max: number
  scalp_target_pct: number
  scalp_stop_mult: number
  scalp_max_daily_trades: number
  scalp_max_daily_loss_pct: number
}

/** Keys whose value is numeric — the only ones the slider/number inputs may set. */
type NumericParamKey = {
  [K in keyof StrategyParams]: StrategyParams[K] extends number ? K : never
}[keyof StrategyParams]

const DEFAULTS: StrategyParams = {
  take_profit_pct: 0.6,
  stop_loss_mult: 2.0,
  roll_delta: 0.4,
  roll_min_dte: 7,
  delta_min: 0.15,
  delta_max: 0.35,
  dte_min: 7,
  dte_max: 45,
  max_concentration_pct: 25.0,
  min_cash_reserve_pct: 10.0,
  scalp_mode: false,
  scalp_min_dte: 0,
  scalp_max_dte: 1,
  scalp_delta_min: 0.2,
  scalp_delta_max: 0.5,
  scalp_target_pct: 0.25,
  scalp_stop_mult: 1.2,
  scalp_max_daily_trades: 6,
  scalp_max_daily_loss_pct: 1.5,
}

export default function StrategyConfigCard() {
  const [params, setParams] = useState<StrategyParams>(DEFAULTS)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    let cancelled = false
    async function load() {
      try {
        // Through lib/api, not a raw fetch(): that bypassed the shared timeout
        // budget and the timed-out-vs-unreachable distinction, so a hung backend
        // left this card spinning with no diagnosis.
        const data = await api.getStrategyConfig()
        if (!cancelled) setParams({ ...DEFAULTS, ...(data.config ?? {}) })
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Failed to load config')
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    load()
    return () => { cancelled = true }
  }, [])

  const set = (key: NumericParamKey) =>
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const num = parseFloat(e.target.value)
      setSaved(false)
      setParams((p) => ({ ...p, [key]: Number.isNaN(num) ? p[key] : num }))
    }

  const handleSave = useCallback(async () => {
    setSaving(true)
    setError(null)
    setSaved(false)
    try {
      // The PUT was the worse of the two raw fetches: a mutating write with no
      // timeout can hang forever, leaving the operator unable to tell whether
      // the risk thresholds were saved or not.
      const data = await api.updateStrategyConfig(params as unknown as Record<string, unknown>)
      setParams({ ...DEFAULTS, ...(data.config ?? {}) })
      setSaved(true)
    } catch (e) {
      // The route answers 422 with {detail: {errors: [...]}} on validation
      // failure; ApiError now carries that parsed body instead of a truncated
      // string, so the field-level reasons survive.
      let message = e instanceof Error ? e.message : 'Failed to save config'
      if (e instanceof ApiError) {
        const detail = e.detail as { errors?: unknown } | undefined
        if (Array.isArray(detail?.errors) && detail.errors.length > 0) {
          message = detail.errors.map(String).join('; ')
        }
      }
      setError(message)
    } finally {
      setSaving(false)
    }
  }, [params])

  const pct = (v: number) => `${Math.round(v * 100)}%`

  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-3">
        <div className="flex h-8 w-8 items-center justify-center rounded border border-[#1e293b] bg-[#0f172a]">
          <SlidersHorizontal className="h-4 w-4 text-[#22c55e]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">Overlay Strategy Parameters</h3>
          <p className="text-xs text-[#94a3b8]">Exit rules, entry bands and portfolio guards for the overlay engine.</p>
        </div>
      </div>

      {loading ? (
        <p className="text-xs text-[#94a3b8]">Loading current configuration…</p>
      ) : (
        <div className="space-y-4">
          <Slider label="TAKE PROFIT (% PREMIUM CAPTURED)" value={params.take_profit_pct} min={0.1} max={1} step={0.05}
            display={pct(params.take_profit_pct)} onChange={set('take_profit_pct')} />
          <Slider label="STOP LOSS (× INITIAL PREMIUM)" value={params.stop_loss_mult} min={1} max={5} step={0.25}
            display={`${params.stop_loss_mult.toFixed(2)}x`} onChange={set('stop_loss_mult')} />
          <Slider label={`ROLL DELTA TRIGGER (> ${params.roll_delta.toFixed(2)})`} value={params.roll_delta} min={0.1} max={0.8} step={0.05}
            display={params.roll_delta.toFixed(2)} onChange={set('roll_delta')} />
          <div className="grid grid-cols-2 gap-3">
            <NumberField label="DELTA BAND MIN" value={params.delta_min} min={0.01} max={1} step={0.01} onChange={set('delta_min')} />
            <NumberField label="DELTA BAND MAX" value={params.delta_max} min={0.01} max={1} step={0.01} onChange={set('delta_max')} />
            <NumberField label="DTE BAND MIN" value={params.dte_min} min={1} max={180} step={1} onChange={set('dte_min')} />
            <NumberField label="DTE BAND MAX" value={params.dte_max} min={1} max={365} step={1} onChange={set('dte_max')} />
          </div>
          <Slider label="MAX CONCENTRATION PER TICKER" value={params.max_concentration_pct} min={5} max={100} step={5}
            display={`${params.max_concentration_pct}%`} onChange={set('max_concentration_pct')} />
          <Slider label="MIN CASH RESERVE" value={params.min_cash_reserve_pct} min={0} max={50} step={1}
            display={`${params.min_cash_reserve_pct}%`} onChange={set('min_cash_reserve_pct')} />

          <div className="rounded border border-[#1e293b] bg-[#020617] p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-semibold text-white">Scalping Mode</h3>
                <p className="text-[10px] text-[#64748b]">Opportunistic short-DTE overlay entries when enabled.</p>
              </div>
              <label className="flex items-center gap-2">
                <input type="checkbox" checked={params.scalp_mode} onChange={(e) => setParams(p => ({...p, scalp_mode: e.target.checked}))} className="h-3.5 w-3.5 accent-[#22c55e]" />
                <span className="text-[10px] text-[#94a3b8]">{params.scalp_mode ? 'ON' : 'OFF'}</span>
              </label>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <NumberField label="SCALP DTE MAX" value={params.scalp_max_dte} min={0} max={7} step={1} onChange={set('scalp_max_dte')} />
              <NumberField label="SCALP DELTA MIN" value={params.scalp_delta_min} min={0.05} max={1} step={0.05} onChange={set('scalp_delta_min')} />
              <NumberField label="SCALP TARGET %" value={params.scalp_target_pct} min={0.05} max={1} step={0.05} onChange={set('scalp_target_pct')} />
              <NumberField label="SCALP STOP MULT" value={params.scalp_stop_mult} min={1} max={5} step={0.25} onChange={set('scalp_stop_mult')} />
              <NumberField label="SCALP MAX DAILY TRADES" value={params.scalp_max_daily_trades} min={1} max={50} step={1} onChange={set('scalp_max_daily_trades')} />
              <NumberField label="SCALP MAX DAILY LOSS %" value={params.scalp_max_daily_loss_pct} min={0.1} max={10} step={0.1} onChange={set('scalp_max_daily_loss_pct')} />
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 rounded border border-red-900/60 bg-red-950/40 px-3 py-2 text-xs text-red-300">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
          {saved && !error && (
            <div className="flex items-center gap-2 rounded border border-green-900/60 bg-green-950/40 px-3 py-2 text-xs text-green-300">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>Strategy configuration saved.</span>
            </div>
          )}

          <button
            onClick={handleSave}
            disabled={saving}
            className="btn-primary inline-flex items-center gap-2 disabled:opacity-50"
          >
            <Save className="h-4 w-4" />
            {saving ? 'Saving…' : 'Save Strategy Parameters'}
          </button>
        </div>
      )}
    </div>
  )
}

function Slider(props: {
  label: string; value: number; min: number; max: number; step: number;
  display: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between">
        <label className="text-xs text-[#94a3b8]">{props.label}</label>
        <span className="font-mono text-xs text-[#22c55e]">{props.display}</span>
      </div>
      <input type="range" className="w-full accent-[#22c55e]" min={props.min}
        max={props.max} step={props.step} value={props.value} onChange={props.onChange} />
    </div>
  )
}

function NumberField(props: {
  label: string; value: number; min: number; max: number; step: number;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
}) {
  return (
    <div>
      <label className="block text-xs text-[#94a3b8] mb-1">{props.label}</label>
      <input type="number" className="input w-full font-mono" min={props.min}
        max={props.max} step={props.step} value={props.value} onChange={props.onChange} />
    </div>
  )
}
