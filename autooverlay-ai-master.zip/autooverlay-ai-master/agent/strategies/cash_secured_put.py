"""
Cash-Secured Put Screening Strategy.

Pure logic: takes a list of put-option dicts (option-chain snapshot) and an
account-cash figure and returns ranked recommendations. No I/O.

Criteria:
- Put |delta| between MIN_DELTA and MAX_DELTA (default 0.15-0.35).
- DTE within [min_dte, max_dte].
- Strike below cost basis where the underlying is held (prefer getting paid
  to buy more below what you already pay); otherwise strike below spot (OTM).
- Cash requirement: strike * 100 <= available cash per contract.
- Ranked by annualized cash-secured yield (premium / strike * 365 / DTE).

Each output row carries an explicit integer risk score 0-100 and a written
rationale for the recommendation label.
"""

from typing import Dict, List, Optional
from datetime import datetime

try:
    from ..config import StrategyConfig
except ImportError:  # pragma: no cover - direct-script imports
    from config import StrategyConfig


class CashSecuredPutStrategy:
    MIN_DELTA = 0.15
    MAX_DELTA = 0.35

    def __init__(
        self,
        min_dte: Optional[int] = None,
        max_dte: Optional[int] = None,
        min_delta: Optional[float] = None,
        max_delta: Optional[float] = None,
        min_annualized_yield: float = 0.12,
        good_annualized_yield: float = 0.25,
        max_risk_for_entry: int = 60,
        config: "StrategyConfig | None" = None,
        tier_policy: "dict | object | None" = None,
    ):
        """
        ``tier_policy``: optional council volatility-tier policy (a
        ``agent.council.handoff.TierPolicy`` or an equivalent dict). When
        given, its delta band / DTE ceiling / size multiplier take effect
        unless explicitly overridden by the matching keyword args; explicit
        args and StrategyConfig defaults still win otherwise.
        """
        cfg = config or StrategyConfig()
        pol = self._normalize_policy(tier_policy)
        self.tier_policy = pol
        # Precedence: explicit arg > tier policy > StrategyConfig defaults.
        self.min_dte = min_dte if min_dte is not None else (
            pol["dte_min"] if pol and pol.get("dte_min") else cfg.dte_min)
        self.max_dte = max_dte if max_dte is not None else (
            pol["max_dte"] if pol else cfg.dte_max)
        self.min_delta = min_delta if min_delta is not None else (
            pol["delta_min"] if pol else cfg.delta_min)
        self.max_delta = max_delta if max_delta is not None else (
            pol["delta_max"] if pol else cfg.delta_max)
        self.size_multiplier = float(pol.get("size_multiplier", 1.0)) if pol else 1.0
        self.min_annualized_yield = min_annualized_yield
        self.good_annualized_yield = good_annualized_yield
        self.max_risk_for_entry = max_risk_for_entry

    @staticmethod
    def _normalize_policy(tier_policy) -> "dict | None":
        """Accept a TierPolicy dataclass or a plain dict; return dict or None."""
        if tier_policy is None:
            return None
        if hasattr(tier_policy, "to_dict"):
            tier_policy = tier_policy.to_dict()
        try:
            allowed = tuple(s.upper() for s in
                            tier_policy.get("allowed_strategies", ()))
        except AttributeError:
            allowed = ()
        return {
            "delta_min": float(tier_policy.get("delta_min", 0.15)),
            "delta_max": float(tier_policy.get("delta_max", 0.35)),
            "max_dte": int(tier_policy.get("max_dte", 45)),
            "size_multiplier": float(tier_policy.get("size_multiplier", 1.0)),
            "allowed_strategies": allowed,
        }

    # ------------------------------------------------------------------ #
    # Public API                                                          #
    # ------------------------------------------------------------------ #
    def screen(self, opportunities: List[Dict], account_cash: float,
               positions: List[Dict] | None = None,
               as_of: datetime | None = None) -> List[Dict]:
        """
        Screen candidate put contracts against cash availability and,
        optionally, existing holdings' cost basis.

        Returns recommendations sorted by annualized yield, desc.
        """
        as_of = as_of or datetime.utcnow()
        basis_by_symbol = {
            p["symbol"]: float(p.get("avg_entry_price") or 0)
            for p in (positions or []) if p.get("symbol")
        }

        results: List[Dict] = []
        for opp in opportunities:
            dte = self._dte(opp, as_of)
            if dte is None or not (self.min_dte <= dte <= self.max_dte):
                continue

            delta = abs(float(opp.get("delta") or 0))
            if not (self.min_delta <= delta <= self.max_delta):
                continue

            underlying = float(opp.get("underlying_price") or 0)
            strike = float(opp.get("strike_price") or 0)
            premium = self._premium(opp)
            if strike <= 0 or premium <= 0:
                continue

            cash_required = strike * 100.0
            contracts_affordable = int(account_cash // cash_required) if cash_required > 0 else 0
            if contracts_affordable < 1:
                continue
            # Council tier size multiplier (half-size on restricted tiers).
            contracts = max(1, int(contracts_affordable * self.size_multiplier))

            symbol = opp.get("symbol")

            # Council tier gate: high-vol tier blocks new short-put exposure.
            if (self.tier_policy
                    and "CSP" not in self.tier_policy["allowed_strategies"]):
                results.append({
                    "strategy": "CASH_SECURED_PUT",
                    "symbol": symbol,
                    "option_symbol": opp.get("option_symbol"),
                    "strike_price": strike,
                    "expiration_date": opp.get("expiration_date"),
                    "dte": dte,
                    "delta": round(delta, 3),
                    "recommendation": "BLOCKED_BY_COUNCIL_TIER",
                    "rationale": (
                        f"{symbol}: CSP blocked — council handoff restricts "
                        f"this volatility tier to "
                        f"{','.join(self.tier_policy['allowed_strategies'])} "
                        f"only (no new short-put exposure pending re-score)."),
                    "reasoning_trace": [
                        f"council tier gate: allowed strategies = "
                        f"{','.join(self.tier_policy['allowed_strategies'])}; "
                        f"CSP not permitted → ✗ BLOCKED",
                        f"council rule cited: Investment Council Report §6/§8 "
                        f"— 'Do not add short-put exposure' on this vol tier",
                    ],
                })
                continue

            cost_basis = basis_by_symbol.get(symbol, 0.0)
            strike_below_basis = strike < cost_basis if cost_basis > 0 else None
            otm = strike < underlying if underlying > 0 else None

            ann_yield = (premium / strike) * (365.0 / dte)
            risk_score = self._risk_score(
                iv=float(opp.get("implied_volatility") or 0), delta=delta,
                dte=dte, underlying=underlying, strike=strike,
                strike_below_basis=strike_below_basis,
            )
            recommendation = self._recommendation(ann_yield, risk_score)

            reasoning_trace = [
                f"DTE {dte} within {self.min_dte}-{self.max_dte} band ✓",
                f"|delta| {delta:.2f} within {self.min_delta:.2f}-"
                f"{self.max_delta:.2f} band ✓",
                f"cash check: ${cash_required:,.0f} collateral per contract, "
                f"{contracts_affordable} contract(s) affordable on "
                f"${account_cash:,.0f} cash "
                f"{'✓' if contracts_affordable >= 1 else '✗'}",
                *( [f"council tier sizing: size multiplier x{self.size_multiplier} "
                    f"applied → {contracts} contract(s) "
                    f"(council handoff restricted-size tier)"]
                   if self.size_multiplier < 1 else [] ),
                f"premium ${premium:.2f}/share → annualized cash-secured yield "
                f"{ann_yield*100:.1f}% (floor {self.min_annualized_yield*100:.0f}%) "
                f"{'✓' if ann_yield >= self.min_annualized_yield else '✗'}",
                f"strike ${strike:.2f} vs cost basis " +
                (f"${cost_basis:.2f}: below basis — accumulating at a discount ✓"
                 if strike_below_basis else
                 f"${cost_basis:.2f}: ABOVE basis (+15 risk) ✗"
                 if strike_below_basis is False else
                 "n/a — no existing position"),
                f"risk score {risk_score}/100 from IV, delta, DTE gamma, basis "
                f"and cushion components",
                f"verdict: {recommendation}",
            ]

            rationale = self._rationale(
                symbol=symbol, strike=strike, dte=dte, delta=delta,
                premium=premium, ann_yield=ann_yield, risk_score=risk_score,
                strike_below_basis=strike_below_basis, otm=otm,
                contracts=contracts, recommendation=recommendation,
                iv=float(opp.get("implied_volatility") or 0),
            )

            results.append({
                "strategy": "CASH_SECURED_PUT",
                "symbol": symbol,
                "option_symbol": opp.get("option_symbol"),
                "contracts": contracts,
                "tier_size_multiplier": self.size_multiplier,
                "cash_required": round(cash_required, 2),
                "strike_price": strike,
                "expiration_date": opp.get("expiration_date"),
                "dte": dte,
                "delta": round(delta, 3),
                "implied_volatility": round(float(opp.get("implied_volatility") or 0), 4),
                "premium_per_share": round(premium, 2),
                "annualized_premium_yield": round(ann_yield, 4),
                "strike_below_cost_basis": strike_below_basis,
                "risk_score": risk_score,
                "recommendation": recommendation,
                "rationale": rationale,
                "reasoning_trace": reasoning_trace,
            })

        return sorted(results, key=lambda r: r.get("annualized_premium_yield", 0), reverse=True)

    # ------------------------------------------------------------------ #
    # Helpers                                                             #
    # ------------------------------------------------------------------ #
    @staticmethod
    def _dte(opp: Dict, as_of: datetime) -> int | None:
        dte = opp.get("days_to_expiry") or opp.get("dte")
        if dte is not None:
            return int(dte)
        exp = opp.get("expiration_date")
        if not exp:
            return None
        try:
            expiry = datetime.fromisoformat(str(exp).replace("Z", "+00:00"))
            naive_expiry = expiry.replace(tzinfo=None)
            return (naive_expiry - as_of.replace(tzinfo=None)).days
        except ValueError:
            return None

    @staticmethod
    def _premium(opp: Dict) -> float:
        for key in ("premium_received_per_share", "last_price"):
            if opp.get(key):
                return float(opp[key])
        bid, ask = opp.get("bid"), opp.get("ask")
        if bid is not None and ask is not None:
            return (float(bid) + float(ask)) / 2.0
        return 0.0

    def _risk_score(self, *, iv: float, delta: float, dte: int,
                    underlying: float, strike: float,
                    strike_below_basis: bool | None) -> int:
        """Composite risk 0-100 (higher = riskier). Deterministic."""
        score = 0.0
        # IV: up to 30 pts (50% IV -> max). Elevated IV raises assignment odds.
        score += min(iv / 0.50, 1.0) * 30
        # Delta proximity to the money: up to 25 pts.
        score += min((delta - self.MIN_DELTA) / (self.MAX_DELTA - self.MIN_DELTA), 1.0) * 25
        # Short-dated gamma risk: up to 20 pts (<21 DTE ramps up).
        score += min(max(0.0, (21 - dte) / 21), 1.0) * 20
        # Strike above cost basis means buying more ABOVE what you already pay: up to 15 pts.
        if strike_below_basis is False:
            score += 15
        # Thin cushion (<3% OTM): up to 10 pts.
        if underlying > 0:
            cushion = (underlying - strike) / underlying
            score += min(max(0.0, (0.03 - cushion) / 0.03), 1.0) * 10
        return int(round(min(score, 100)))

    def _recommendation(self, ann_yield: float, risk_score: int) -> str:
        if ann_yield >= self.good_annualized_yield and risk_score <= self.max_risk_for_entry:
            return "INITIATE_POSITION"
        if ann_yield >= self.min_annualized_yield and risk_score <= 75:
            return "HOLD_POSITION"
        return "MONITOR_CLOSELY"

    @staticmethod
    def _rationale(**kw) -> str:
        basis_txt = (
            "below your cost basis (accumulating at a discount)"
            if kw["strike_below_basis"] else
            "ABOVE your cost basis (would add shares above current average)"
            if kw["strike_below_basis"] is False else
            "with no existing position to compare basis"
        )
        otm_txt = ("out-of-the-money" if kw["otm"] else "in-the-money"
                   if kw["otm"] is False else "moneyness unknown")
        return (
            f"{kw['symbol']}: sell {kw['contracts']} cash-secured put(s) at ${kw['strike']:.2f} "
            f"({basis_txt}, {otm_txt}), {kw['dte']} DTE, |delta| {kw['delta']:.2f}. "
            f"Premium ${kw['premium']:.2f}/share = {kw['ann_yield']*100:.1f}% annualized "
            f"cash-secured yield; ${kw['strike']*100:,.0f} collateral per contract. "
            f"Risk score {kw['risk_score']}/100 (IV {kw['iv']*100:.0f}%, gamma near expiry, cushion). "
            f"=> {kw['recommendation']}"
        )
